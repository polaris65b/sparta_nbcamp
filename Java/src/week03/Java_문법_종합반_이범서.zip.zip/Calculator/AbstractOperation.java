package week03.Calculator;

public abstract class AbstractOperation {
    public abstract double operate(int firstNumber, int secondNumber);
}
